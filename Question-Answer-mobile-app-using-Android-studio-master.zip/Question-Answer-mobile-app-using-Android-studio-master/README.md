# MadForumApp
This is a forum where users can share their knowledge and clear any doubts
