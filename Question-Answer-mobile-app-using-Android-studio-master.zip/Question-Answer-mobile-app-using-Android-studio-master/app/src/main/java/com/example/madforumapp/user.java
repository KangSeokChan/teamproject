package com.example.madforumapp;

public class user {

    public String Name,Email,Phone;

    public user()
    {

    }

    public user(String Name,String Email,String Phone )
    {
        this.Name=Name;
        this.Email=Email;
        this.Phone=Phone;

    }
}
